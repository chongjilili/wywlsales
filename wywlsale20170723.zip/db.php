<?php
 
return array (
    'DB_TYPE' => 'mysqli',
    'DB_HOST' => '127.0.0.1',
    'DB_PORT' => '3306',
    'DB_USER' => 'wanyuwl',
    'DB_PWD' => 'wywl1234',
    'DB_NAME' => 'wy1598',
    'DB_PREFIX' => 'wywl_',
    'DB_CHARSET' => 'utf8',
);