<?php
 
return array (
    'DB_TYPE' => 'mysqli',
    'DB_HOST' => '127.0.0.1',
    'DB_PORT' => '3306',
    'DB_USER' => 'root',
    'DB_PWD' => '6689310',
    'DB_NAME' => 'wywlsales',
    'DB_PREFIX' => 'wywl_',
    'DB_CHARSET' => 'utf8',
);